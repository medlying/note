#!/bin/bash
priority=$1
vip=$2


ifconfig=`which ifconfig`
mongo=`which mongo`

echo "|-----------------|"
echo "|--Stop firewall--|"
echo "|-----------------|"

systemctl  stop SuSEfirewall2.service
systemctl disable SuSEfirewall2.service

# install mongodb

echo "|-----------------|"
echo "|import public key|"
echo "|-----------------|"
sudo rpm --import https://www.mongodb.org/static/pgp/server-3.4.asc

echo "|-----------------|"
echo "|add mongodb  repo|"
echo "|-----------------|"

# sudo zypper addrepo -f https://ftp5.gwdg.de/pub/opensuse/discontinued/distribution/12.3/repo/oss/ oss
# sudo zypper addrepo -f https://ftp5.gwdg.de/pub/opensuse/discontinued/distribution/12.3/repo/non-oss/ non-oss
sudo zypper addrepo --gpgcheck "https://repo.mongodb.org/zypper/suse/12/mongodb-org/3.4/x86_64/" mongodb
sudo zypper -n install mongodb-org
cp /etc/mongod.conf{,.`date +%F`}
echo "|-------------------------|"
echo "|add mongodb data directory|"
echo "|-------------------------|"
mkdir -pv /data/mongodb/{data,logs}


echo "|-------------------------|"
echo "config mongodb configure files"
echo "|-------------------------|"

cat << EOF > /etc/mongod.conf
dbpath=/data/mongodb/data
logpath=/data/mongodb/logs/mongodb.log
pidfilepath=/var/run/mongodb.pid
directoryperdb=true
logappend=true
replSet=rs1
bind_ip=0.0.0.0
smallfiles=true
port=27017
oplogSize=5120
fork=true
journal=true
EOF

echo "|-------------------------|"
echo "install keepalived"
echo "|-------------------------|"

zypper install http://download.opensuse.org/repositories/home:/Herbster0815:/SLES:/12/SLE_12_SP3/x86_64/keepalived-2.0.2-54.1.x86_64.rpm
echo "backup keepalived configure files"
cp /etc/keepalived/keepalived.conf{,`date +%F`}

echo "|-------------------------|"
echo "configure vrrp_script"
echo "|-------------------------|"

cat << EOF > /data/mongodb/check_mongos.sh
#!/bin/bash
A=\`ps -C mongo --no-header |wc -l\`
if [ $A -eq 0 ];then
     systemctl stop keepalived.service
fi
EOF
echo "|-------------------------|"
echo "add exec privileges for check_mongos.sh"
echo "|-------------------------|"
chmod 755 /data/mongodb/check_mongos.sh

echo "|-------------------------|"
echo "backup keepalvied.cfg"
echo "|-------------------------|"

cat << EOF > /etc/keepalived/keepalived.conf
! Configuration File for keepalived
global_defs {
   notification_email {
    demo@163.com
   }
   notification_email_from demo@163.com
   smtp_server smtp.163.com
   smtp_connect_timeout 65
   router_id mongodb1
}
vrrp_script check{
    script "/data/mongodb/check_mongos.sh"
    interval 2
    weight 2
}
vrrp_instance http {
    state MASTER
    interface eth0
    virtual_router_id 51
    priority $priority
    advert_int 1
    authentication {
        auth_type PASS
        auth_pass lKZvQVv9
    }
    virtual_ipaddress {
        $vip/24 dev eth0
    }
    track_script {
        check
}
}
EOF


echo "|-------------------------|"
echo "start mongod"
echo "|-------------------------|"
`which mongod` -f /etc/mongod.conf
# systemctl start mongod.service
systemctl start keepalived.service
# systemctl enable mongod.service
systemctl enable keepalived.service

# echo "db.serverStatus()" | `which mongo` admin
echo "|-------------------------|"
echo "check whether mongo service running is ok"
echo "|-------------------------|"

ps -ef | grep mongo | grep -v grep
if [ `echo $?` -eq 0 ];then
  echo "mongodb Running now"
else
  echo "mongodb start failed"
  exit 3
fi

# echo "|-------------------------|"
# echo "initiate replica set cluster"
# echo "|-------------------------|"

# config={_id:\"rs1\",members:[{_id:0,\"host\":\"$1:27017\"},{_id:1,\"host\":\"$2:27017\"},{_id:2,\"host\":\"$3:27017\"}]}
# `echo "rs.initiate($config)" | $mongo --host $vip --port 27017 admin` > /tmp/initiate.log
# if `grep 'ok' /tmp/initiate.log`;then
#   echo "initiate done."
# else
#   echo "initiate failed"
# fi

# echo "|-------------------------|"
# echo "show replica set status"
# echo "|-------------------------|"

# echo "rs.status()" | $mongo --host $vip --port 27017 admin && netstat -tunlp | grep mongo | grep -v grep

# if [ `echo $?` -eq 0 ];then
#   echo "deploy done."
# else
#   echo "replica set deploy failed"

